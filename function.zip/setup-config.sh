#!/bin/bash

# Set up Pulumi configuration for PReQual Phase 2

echo "Setting up Pulumi configuration for PReQual Phase 2..."

# Generate a webhook secret
WEBHOOK_SECRET=$(openssl rand -hex 20)
echo "Generated GitHub webhook secret: $WEBHOOK_SECRET"

# Generate SQL admin password
SQL_PASSWORD=$(openssl rand -base64 16)
echo "Generated SQL admin password: $SQL_PASSWORD"

# Set Azure credentials
echo "Setting Azure credentials..."
pulumi config set azure-native:clientId a31cc29f-2efb-47e7-8871-63e15650fb9d
pulumi config set azure-native:clientSecret 2GK8Q~UxSkh6~fyaZk.avZWO73Cbm3rT8cRFjcsf --secret
pulumi config set azure-native:tenantId a5bd300c-c3b3-41d8-87e0-1f5c8d364af3
pulumi config set azure-native:subscriptionId 98c61d81-12c6-4aa2-8ac6-8dc7b8f5e834

# Set PR monitoring configuration
echo "Setting PR monitoring configuration..."
pulumi config set githubWebhookSecret $WEBHOOK_SECRET --secret
pulumi config set slackWebhookUrl https://hooks.slack.com/services/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 --secret
pulumi config set sqlAdminUsername prequel_admin
pulumi config set sqlAdminPassword $SQL_PASSWORD --secret
pulumi config set location "East US"
pulumi config set organizationName "Shetchuko"

echo "Configuration complete! You can verify with 'pulumi config'"