module.exports = async function (context, req) {
  // Add detailed logging
  context.log('=================== PREQUEL WEBHOOK RECEIVED ===================');
  context.log(`Timestamp: ${new Date().toISOString()}`);
  
  // Log full request details
  context.log('Headers:', JSON.stringify(req.headers, null, 2));
  context.log('Body:', JSON.stringify(req.body, null, 2));
  
  // Add a marker to verify this is your specific implementation
  context.log('PREQUEL PROJECT WEBHOOK HANDLER - VERIFYING DEPLOYMENT');
  
  try {
    // Specific handling based on event type
    if (req.body && req.body.action) {
      context.log(`Received GitHub action: ${req.body.action}`);
    }
    
    context.res = {
      status: 200,
      body: {
        message: 'Prequel Webhook Processed Successfully',
        timestamp: new Date().toISOString(),
        source: 'Prequel Webhook Handler'
      }
    };
  } catch (error) {
    context.log.error('Webhook processing error:', error);
    context.res = {
      status: 500,
      body: {
        error: 'Processing failed',
        details: error.message
      }
    };
  }
  
  context.log('=================== WEBHOOK PROCESSING COMPLETE ===================');
};
