import { AzureFunction } from "@azure/functions";
/**
 * Webhook handler for GitHub events
 */
declare const httpTrigger: AzureFunction;
export default httpTrigger;
