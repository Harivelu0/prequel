export declare function getErrorMessage(error: unknown): string;
