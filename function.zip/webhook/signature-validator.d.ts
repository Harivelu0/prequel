export declare function validateGitHubSignature(payload: any, signature: string): Promise<boolean>;
