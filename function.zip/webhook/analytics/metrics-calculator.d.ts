import { AzureFunction } from "@azure/functions";
/**
 * Timer-triggered function to calculate PR metrics and generate reports
 */
declare const timerTrigger: AzureFunction;
export default timerTrigger;
